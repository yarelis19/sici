﻿namespace FinalProject
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.txtBoxLastName = new System.Windows.Forms.TextBox();
            this.txtBoxHours = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.labelPay = new System.Windows.Forms.Label();
            this.labelHours = new System.Windows.Forms.Label();
            this.checkInsurance = new System.Windows.Forms.CheckBox();
            this.checkBonus = new System.Windows.Forms.CheckBox();
            this.btnSaveAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.txtBoxYears = new System.Windows.Forms.TextBox();
            this.labelYears = new System.Windows.Forms.Label();
            this.numericPayRate = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericPayRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // txtBoxName
            // 
            this.txtBoxName.Location = new System.Drawing.Point(156, 90);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(142, 23);
            this.txtBoxName.TabIndex = 0;
            this.txtBoxName.TextChanged += new System.EventHandler(this.txtBoxName_TextChanged);
            // 
            // txtBoxLastName
            // 
            this.txtBoxLastName.Location = new System.Drawing.Point(444, 90);
            this.txtBoxLastName.Name = "txtBoxLastName";
            this.txtBoxLastName.Size = new System.Drawing.Size(144, 23);
            this.txtBoxLastName.TabIndex = 1;
            this.txtBoxLastName.TextChanged += new System.EventHandler(this.txtBoxLastName_TextChanged);
            // 
            // txtBoxHours
            // 
            this.txtBoxHours.Location = new System.Drawing.Point(124, 186);
            this.txtBoxHours.Name = "txtBoxHours";
            this.txtBoxHours.Size = new System.Drawing.Size(100, 23);
            this.txtBoxHours.TabIndex = 3;
            this.txtBoxHours.TextChanged += new System.EventHandler(this.txtBoxHours_TextChanged);
            this.txtBoxHours.Enter += new System.EventHandler(this.hours_enter);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelName.Location = new System.Drawing.Point(43, 85);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(107, 25);
            this.labelName.TabIndex = 4;
            this.labelName.Text = "First Name";
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelLastName.Location = new System.Drawing.Point(331, 88);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(104, 25);
            this.labelLastName.TabIndex = 5;
            this.labelLastName.Text = "Last Name";
            // 
            // labelPay
            // 
            this.labelPay.AutoSize = true;
            this.labelPay.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelPay.Location = new System.Drawing.Point(43, 139);
            this.labelPay.Name = "labelPay";
            this.labelPay.Size = new System.Drawing.Size(104, 25);
            this.labelPay.TabIndex = 6;
            this.labelPay.Text = "Pay Rate $";
            this.labelPay.Click += new System.EventHandler(this.labelPay_Click);
            // 
            // labelHours
            // 
            this.labelHours.AutoSize = true;
            this.labelHours.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelHours.Location = new System.Drawing.Point(43, 186);
            this.labelHours.Name = "labelHours";
            this.labelHours.Size = new System.Drawing.Size(67, 25);
            this.labelHours.TabIndex = 7;
            this.labelHours.Text = "Hours";
            // 
            // checkInsurance
            // 
            this.checkInsurance.AutoSize = true;
            this.checkInsurance.Location = new System.Drawing.Point(43, 231);
            this.checkInsurance.Name = "checkInsurance";
            this.checkInsurance.Size = new System.Drawing.Size(122, 19);
            this.checkInsurance.TabIndex = 8;
            this.checkInsurance.Text = "Medical Insurance";
            this.checkInsurance.UseVisualStyleBackColor = true;
            // 
            // checkBonus
            // 
            this.checkBonus.AutoSize = true;
            this.checkBonus.Location = new System.Drawing.Point(195, 231);
            this.checkBonus.Name = "checkBonus";
            this.checkBonus.Size = new System.Drawing.Size(218, 19);
            this.checkBonus.TabIndex = 9;
            this.checkBonus.Text = "Bonus (More than 5 Years of Service)";
            this.checkBonus.UseVisualStyleBackColor = true;
            // 
            // btnSaveAdd
            // 
            this.btnSaveAdd.Location = new System.Drawing.Point(137, 358);
            this.btnSaveAdd.Name = "btnSaveAdd";
            this.btnSaveAdd.Size = new System.Drawing.Size(75, 23);
            this.btnSaveAdd.TabIndex = 10;
            this.btnSaveAdd.Text = "Save";
            this.btnSaveAdd.UseVisualStyleBackColor = true;
            this.btnSaveAdd.Click += new System.EventHandler(this.btnSaveAdd_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(291, 358);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear Fields";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(444, 358);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 12;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // txtBoxYears
            // 
            this.txtBoxYears.Location = new System.Drawing.Point(488, 144);
            this.txtBoxYears.Name = "txtBoxYears";
            this.txtBoxYears.Size = new System.Drawing.Size(100, 23);
            this.txtBoxYears.TabIndex = 15;
            this.txtBoxYears.TextChanged += new System.EventHandler(this.txtBoxYears_TextChanged);
            // 
            // labelYears
            // 
            this.labelYears.AutoSize = true;
            this.labelYears.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelYears.Location = new System.Drawing.Point(331, 141);
            this.labelYears.Name = "labelYears";
            this.labelYears.Size = new System.Drawing.Size(151, 25);
            this.labelYears.TabIndex = 16;
            this.labelYears.Text = "Years of Service";
            // 
            // numericPayRate
            // 
            this.numericPayRate.DecimalPlaces = 2;
            this.numericPayRate.Location = new System.Drawing.Point(153, 144);
            this.numericPayRate.Name = "numericPayRate";
            this.numericPayRate.Size = new System.Drawing.Size(120, 23);
            this.numericPayRate.TabIndex = 17;
            this.numericPayRate.Value = new decimal(new int[] {
            155,
            0,
            0,
            65536});
            this.numericPayRate.ValueChanged += new System.EventHandler(this.numericPayRate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightGray;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(140, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 39);
            this.label1.TabIndex = 18;
            this.label1.Text = "Employee Records";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FinalProject.Properties.Resources.Ok_icon;
            this.pictureBox1.Location = new System.Drawing.Point(444, 286);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FinalProject.Properties.Resources.Actions_edit_clear_locationbar_ltr_icon;
            this.pictureBox2.Location = new System.Drawing.Point(291, 286);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 66);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::FinalProject.Properties.Resources.floppy_icon;
            this.pictureBox3.Location = new System.Drawing.Point(140, 286);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(72, 66);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::FinalProject.Properties.Resources.Order_history_icon;
            this.pictureBox4.Location = new System.Drawing.Point(56, 10);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 72);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 22;
            this.pictureBox4.TabStop = false;
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 410);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericPayRate);
            this.Controls.Add(this.labelYears);
            this.Controls.Add(this.txtBoxYears);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSaveAdd);
            this.Controls.Add(this.checkBonus);
            this.Controls.Add(this.checkInsurance);
            this.Controls.Add(this.labelHours);
            this.Controls.Add(this.labelPay);
            this.Controls.Add(this.labelLastName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.txtBoxHours);
            this.Controls.Add(this.txtBoxLastName);
            this.Controls.Add(this.txtBoxName);
            this.Name = "AddForm";
            this.Text = "Add A Form";
            ((System.ComponentModel.ISupportInitialize)(this.numericPayRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtBoxName;
        private TextBox txtBoxLastName;
        private TextBox txtBoxHours;
        private Label labelName;
        private Label labelLastName;
        private Label labelPay;
        private Label labelHours;
        private CheckBox checkInsurance;
        private CheckBox checkBonus;
        private Button btnSaveAdd;
        private Button btnClear;
        private Button btnDone;
        private TextBox txtBoxYears;
        private Label labelYears;
        private NumericUpDown numericPayRate;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}