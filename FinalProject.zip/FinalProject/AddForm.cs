﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class AddForm : Form
    {
        const double MaxHours = 60.0;
        const double MaxPayRate = 50.00;
        const double RegularHours = 50.0;
        const double OverTimeRate = 1.5;
        const double MedicalCost = 30.00;
        const double ServiceBonus = 50.00;
        public AddForm()
        {
            InitializeComponent();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Are you sure you want to exit?");
            this.Close();
        }
        private void clearAll()
        {
            txtBoxName.Clear();
            txtBoxLastName.Clear();
            numericPayRate.Text ="0";
            txtBoxHours.Text= "0";
            txtBoxYears.Text = " ";
            checkBonus.Checked= false;
            checkInsurance.Checked= false;
            txtBoxName.Focus();
            
        }
        
        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();


        }
        
        private void btnSaveAdd_Click(object sender, EventArgs e)
        {
            string finalInfo = txtBoxLastName.Text + ", " + txtBoxName.Text + ", " +
                numericPayRate.Text + ", " + txtBoxHours.Text + " hours,";

            finalInfo += checkBonus.Checked ? "Bonus, " : "No Bonus, ";
            finalInfo += checkInsurance.Checked ? "Insurance,  " : " No Insurance, " ;
            finalInfo += string.Format("{0:C}", calculatePay(double.Parse(txtBoxHours.Text), double.Parse(numericPayRate.Text)));

            if (txtBoxName.Text == "" || txtBoxLastName.Text == "" || txtBoxHours.Text == "" || numericPayRate.Text == ""|| txtBoxYears.Text == "")
            {
                MessageBox.Show("Some of the fields are incomplete. Please verify you entered an input.");
            }else
            {
                ShowRecordsForm saveRec = new ShowRecordsForm();
                saveRec.receiveRecords(finalInfo);
                MessageBox.Show("Saved record --> " + finalInfo);
                clearAll();
            }
        }



        private void txtBoxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxHours_TextChanged(object sender, EventArgs e)
        {
            string input = txtBoxHours.Text;
            double workHours;

            //validate input

            if (!(double.TryParse(input, out workHours) &&
                    workHours >= 0.0 && workHours <= MaxHours))
            {
                string message = "Working Hours must be more than zero and less than " + MaxHours.ToString();
                MessageBox.Show(message);
                txtBoxHours.Text = "0";
                txtBoxHours.Focus();
                txtBoxHours.SelectAll();
            }

        }

        private void txtBoxYears_TextChanged(object sender, EventArgs e)
        {
            string input = txtBoxYears.Text;
            double workYears= 0;

            //validate input
            
                if (!(double.TryParse(input, out workYears) &&
                        workYears >= 0))
                {
                    string message = "Working Years must be 0 or more, if you have less than one year enter 0.";
                    MessageBox.Show(message);
                    txtBoxYears.Text = " ";
                    txtBoxYears.Focus();
                    txtBoxYears.SelectAll();
                }
            
        }

        private double calculatePay(double hours, double payRate)
        {
            double earnings = 0;

            if (hours <= RegularHours)
            {
                earnings = hours * payRate;
            }
            else
            {
                earnings = RegularHours * payRate +
                          (hours - RegularHours) * payRate * OverTimeRate;
            }

            if (checkInsurance.Checked)
            {
                if (earnings > MedicalCost) { earnings -= MedicalCost; }
            }

            if (checkBonus.Checked)
            {
                if (int.Parse(txtBoxYears.Text) > 5) { earnings += ServiceBonus; }
            }

            return earnings;
        }

        private void hours_enter(object sender, EventArgs e)
        {
            txtBoxHours.SelectAll();
        }

       // private void payRate_enter(object sender, EventArgs e)
       // {
           // numericPayRate.SelectAll();
       // }

        private void numericPayRate_ValueChanged(object sender, EventArgs e)
        {

         
            numericPayRate.Maximum = 50.00m;
            numericPayRate.Minimum = 8.50m;
            numericPayRate.Increment = 0.50m;
            
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelPay_Click(object sender, EventArgs e)
        {

        }
    }
}
